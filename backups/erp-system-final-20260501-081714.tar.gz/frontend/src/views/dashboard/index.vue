<template>
  <div class="dashboard">
    <div class="page-header">
      <h2>儀表板</h2>
      <span class="date">{{ today }}</span>
    </div>

    <!-- 數據卡片 -->
    <el-row :gutter="20">
      <el-col :xs="24" :sm="12" :md="6">
        <div class="data-card">
          <div class="card-title">今日銷售額</div>
          <div class="card-value">¥{{ formatNumber(stats.today.sales_amount) }}</div>
          <div class="card-change" :class="stats.today.order_count > 0 ? 'up' : ''">
            {{ stats.today.order_count }} 筆訂單
          </div>
        </div>
      </el-col>
      <el-col :xs="24" :sm="12" :md="6">
        <div class="data-card">
          <div class="card-title">本月銷售額</div>
          <div class="card-value">¥{{ formatNumber(stats.this_month.sales_amount) }}</div>
          <div class="card-change" :class="stats.this_month.order_count > 0 ? 'up' : ''">
            {{ stats.this_month.order_count }} 筆訂單
          </div>
        </div>
      </el-col>
      <el-col :xs="24" :sm="12" :md="6">
        <div class="data-card">
          <div class="card-title">庫存總值</div>
          <div class="card-value">¥{{ formatNumber(stats.inventory.total_value) }}</div>
          <div class="card-change">
            {{ stats.inventory.total_quantity }} 件商品
          </div>
        </div>
      </el-col>
      <el-col :xs="24" :sm="12" :md="6">
        <div class="data-card warning">
          <div class="card-title">待處理事項</div>
          <div class="card-value">{{ totalPending }}</div>
          <div class="card-change down">
            請及時處理
          </div>
        </div>
      </el-col>
    </el-row>

    <!-- 待處理事項 -->
    <el-row :gutter="20" class="mt-20">
      <el-col :span="24">
        <el-card>
          <template #header>
            <div class="card-header">
              <span>待處理事項</span>
            </div>
          </template>
          <el-row :gutter="20">
            <el-col :xs="12" :sm="8" :md="4" v-for="(count, name) in stats.pending_tasks" :key="name">
              <div class="pending-item" @click="navigateTo(name)">
                <div class="pending-count" :class="count > 0 ? 'has-count' : ''">{{ count }}</div>
                <div class="pending-label">{{ getPendingLabel(name) }}</div>
              </div>
            </el-col>
          </el-row>
        </el-card>
      </el-col>
    </el-row>

    <!-- 圖表區 -->
    <el-row :gutter="20" class="mt-20">
      <el-col :xs="24" :lg="12">
        <el-card>
          <template #header>
            <div class="card-header">
              <span>近7日銷售趨勢</span>
            </div>
          </template>
          <div ref="salesChartRef" class="chart-container"></div>
        </el-card>
      </el-col>
      <el-col :xs="24" :lg="12">
        <el-card>
          <template #header>
            <div class="card-header">
              <span>支付方式分佈</span>
            </div>
          </template>
          <div ref="paymentChartRef" class="chart-container"></div>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { useRouter } from 'vue-router'
import axios from 'axios'
import * as echarts from 'echarts'
import dayjs from 'dayjs'

const router = useRouter()
const today = dayjs().format('YYYY年MM月DD日')

const salesChartRef = ref()
const paymentChartRef = ref()
let salesChart = null
let paymentChart = null

const stats = ref({
  today: { sales_amount: 0, order_count: 0 },
  this_month: { sales_amount: 0, order_count: 0 },
  inventory: { total_quantity: 0, total_value: 0 },
  pending_tasks: {
    pending_purchase_orders: 0,
    pending_transfer_orders: 0,
    pending_production_orders: 0,
    expiry_warnings: 0,
    low_stock_products: 0
  }
})

const totalPending = computed(() => {
  return Object.values(stats.value.pending_tasks).reduce((sum, count) => sum + count, 0)
})

const formatNumber = (num) => {
  return num?.toLocaleString('zh-CN') || '0'
}

const getPendingLabel = (name) => {
  const labels = {
    pending_purchase_orders: '待審批採購',
    pending_transfer_orders: '待處理調撥',
    pending_production_orders: '待審批生產',
    expiry_warnings: '效期预警',
    low_stock_products: '低庫存预警'
  }
  return labels[name] || name
}

const navigateTo = (name) => {
  const routes = {
    pending_purchase_orders: '/purchase',
    pending_transfer_orders: '/inventory',
    pending_production_orders: '/production',
    expiry_warnings: '/inventory',
    low_stock_products: '/inventory'
  }
  router.push(routes[name] || '/')
}

const fetchDashboardData = async () => {
  try {
    const response = await axios.get('/api/reports/dashboard')
    stats.value = response.data.data
  } catch (error) {
    console.error('獲取儀表板數據失敗:', error)
  }
}

const initCharts = () => {
  // 銷售趨勢圖
  salesChart = echarts.init(salesChartRef.value)
  salesChart.setOption({
    tooltip: { trigger: 'axis' },
    xAxis: {
      type: 'category',
      data: ['周一', '周二', '周三', '周四', '周五', '周六', '周日']
    },
    yAxis: { type: 'value' },
    series: [{
      data: [120, 200, 150, 80, 70, 110, 130],
      type: 'line',
      smooth: true,
      itemStyle: { color: '#ff6b35' },
      areaStyle: {
        color: {
          type: 'linear',
          x: 0, y: 0, x2: 0, y2: 1,
          colorStops: [
            { offset: 0, color: 'rgba(255, 107, 53, 0.3)' },
            { offset: 1, color: 'rgba(255, 107, 53, 0.05)' }
          ]
        }
      }
    }]
  })

  // 支付方式餅圖
  paymentChart = echarts.init(paymentChartRef.value)
  paymentChart.setOption({
    tooltip: { trigger: 'item' },
    legend: { bottom: '5%' },
    series: [{
      type: 'pie',
      radius: ['40%', '70%'],
      avoidLabelOverlap: false,
      itemStyle: {
        borderRadius: 10,
        borderColor: '#fff',
        borderWidth: 2
      },
      label: { show: false },
      data: [
        { value: 1048, name: '現金', itemStyle: { color: '#ff6b35' } },
        { value: 735, name: '微信支付', itemStyle: { color: '#10b981' } },
        { value: 580, name: '支付寶', itemStyle: { color: '#3b82f6' } },
        { value: 484, name: '會員餘額', itemStyle: { color: '#f59e0b' } }
      ]
    }]
  })
}

const handleResize = () => {
  salesChart?.resize()
  paymentChart?.resize()
}

onMounted(() => {
  fetchDashboardData()
  initCharts()
  window.addEventListener('resize', handleResize)
})

onUnmounted(() => {
  window.removeEventListener('resize', handleResize)
  salesChart?.dispose()
  paymentChart?.dispose()
})
</script>

<style scoped lang="scss">
.dashboard {
  .page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
    
    h2 {
      font-size: 20px;
      font-weight: 600;
    }
    
    .date {
      color: var(--text-secondary);
      font-size: 14px;
    }
  }
  
  .data-card {
    background: var(--card-bg);
    border-radius: 8px;
    padding: 20px;
    box-shadow: var(--shadow);
    transition: transform 0.3s;
    
    &:hover {
      transform: translateY(-2px);
    }
    
    &.warning {
      background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
    }
    
    .card-title {
      font-size: 14px;
      color: var(--text-secondary);
      margin-bottom: 8px;
    }
    
    .card-value {
      font-size: 28px;
      font-weight: 600;
      color: var(--text-primary);
    }
    
    .card-change {
      font-size: 12px;
      margin-top: 8px;
      color: var(--text-muted);
      
      &.up {
        color: #10b981;
      }
      
      &.down {
        color: #ef4444;
      }
    }
  }
  
  .mt-20 {
    margin-top: 20px;
  }
  
  .card-header {
    font-weight: 600;
  }
  
  .pending-item {
    text-align: center;
    padding: 15px;
    cursor: pointer;
    border-radius: 8px;
    transition: background-color 0.3s;
    
    &:hover {
      background-color: var(--primary-bg);
    }
    
    .pending-count {
      font-size: 32px;
      font-weight: 600;
      color: var(--text-muted);
      
      &.has-count {
        color: var(--primary-color);
      }
    }
    
    .pending-label {
      font-size: 12px;
      color: var(--text-secondary);
      margin-top: 5px;
    }
  }
  
  .chart-container {
    height: 300px;
  }
}
</style>
